package com.example.mybleapp;



/*public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}*/




import android.annotation.SuppressLint;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothManager;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;

import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;

import android.content.Context;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

// Fuer Joystick

import android.animation.ObjectAnimator;
import android.content.SharedPreferences;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.RelativeLayout;
import android.widget.Button;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;

import androidx.core.app.ActivityCompat;

import java.util.Timer;
import java.util.TimerTask;
import java.util.UUID;

import me.tankery.lib.circularseekbar.CircularSeekBar;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "BTServer";
    private static final String APP_NAME = "PiMowBotRC";
    private static final UUID MY_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");

    private BluetoothAdapter bluetoothAdapter;
    private BluetoothServerSocket serverSocket;
    private BluetoothSocket socket;
    private InputStream inputStream;
    private OutputStream outputStream;
    private Timer timer;                     // Timer zum Ausführen von Aufgaben
    private TimerTask timerTask;
    private int counter =0;
    private boolean isTimerRunning = false;
    private ImageView Compass;

    SharedPreferences sp;
    RelativeLayout layout_joystick;
    TextView text_event, text_progress, heading, tvdirection;

    private BluetoothManager bluetoothManager;
    private BluetoothLeAdvertiser bluetoothLeAdvertiser;
    private BluetoothDevice connectedDevice;
    private String oText = "Start Mowing";  // Ursprünglicher Text des Buttons
    private String lText = "Shut Down";  // Text für langes Drücken
    private Handler handler = new Handler();  // Handler, um verzögerte Aktionen auszuführen
    private boolean isLongPressed = false;  // Status für das lange Drücken
    private boolean isClickEvent = false;  // Status, um das Click-Ereignis zu überwachen





    JoyStickClass js;



    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        //TextView teledata = (TextView) findViewById(R.id.textView);
        Global.ivar1=0;
        bluetoothManager = (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        bluetoothAdapter = bluetoothManager.getAdapter();
        Button mower = (Button) findViewById(R.id.moweron);
        Button Auto = (Button) findViewById(R.id.automow);
        Button Pr_1 = (Button) findViewById(R.id.Prog1);
        Button Pr_2 = (Button) findViewById(R.id.Prog2);
        Button btnStop = (Button) findViewById(R.id.btStopp);

        CircularSeekBar seekBar = (CircularSeekBar) findViewById(R.id.progress_circular);

        TextView textEvent = (TextView) findViewById(R.id.text_event);
        TextView textProgress = (TextView) findViewById(R.id.text_progress);



        mower.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendDataToRaspberryPi("m");
                Log.d(TAG, "Sende an Pi ein m");
            }
        });
        btnStop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataToRaspberryPi("Ma");
                Log.d(TAG, "Stoppe Mower");
            }
        });
        Pr_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataToRaspberryPi("P1");
                Log.d(TAG, "Starte P1");
            }
        });
        Pr_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendDataToRaspberryPi("P2");
                Log.d(TAG, "Starte P2");
            }
        });
        // OnTouchListener, für dem Mower Button der nach längerem Drücken den Text in Shutdown ändern soll
        Auto.setOnTouchListener(new View.OnTouchListener() {
            private Runnable longPressRunnable = new Runnable() {
                @Override
                public void run() {
                    isLongPressed = true;  // Langes Drücken aktiviert
                    if (Auto.getText().equals(lText)){
                        //Toast.makeText(MainActivity.this, "Langes Drücken aktiviert " + Auto.getText(), Toast.LENGTH_SHORT).show();
                        Auto.setText(oText);
                        return;
                    };
                    if (Auto.getText().equals(oText)){
                        Auto.setText(lText);
                        //Toast.makeText(MainActivity.this, "Langes Drücken aktiviert " + Auto.getText(), Toast.LENGTH_SHORT).show();
                        return;
                    };// Text des Buttons änden
                }
            };

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        isLongPressed = false;  // Zurücksetzen des Status
                        isClickEvent = true;    // Setze das Click-Event auf true
                        handler.postDelayed(longPressRunnable, 1000);  // 2000 ms = 2 Sekunden
                        return true;  // Signalisiert, dass das Ereignis verarbeitet wird

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        handler.removeCallbacks(longPressRunnable);  // Beende den Timer
                        if (isLongPressed) {
                            // Der Button wurde lange gedrückt, Text bleibt bei `longPressText`
                            //Toast.makeText(MainActivity.this, "Langes Drücken beendet", Toast.LENGTH_SHORT).show();
                        } else {
                            // Der Button wurde zu kurz gedrückt, es ist also ein kurzes Drücken
                            if (isClickEvent) {
                                // Manuelles Aufrufen des Click-Events, wenn es sich um ein kurzes Drücken handelt
                                Auto.performClick();
                            }
                        }
                        return true;
                }
                return false;
            }
        });

        // Setze einen Click-Listener, um je nach aktuellem Text unterschiedliche Aktionen auszuführen
        Auto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Auto.getText().equals(lText)) {
                    // Aktion für langes Drücken ausführen
                    performLongPressAction(""+ Auto.getText());
                } else {
                    // Aktion für kurzes Drücken ausführen
                    performShortPressAction(""+ Auto.getText());
                    if (Auto.getText().equals("Start Mowing")){
                        sendDataToRaspberryPi("Mo");
                    }
                }
            }
        });
        // GATT-Server initialisieren
        startBTServer();
        MakeBall();

        seekBar.setOnSeekBarChangeListener(new CircularSeekBar.OnCircularSeekBarChangeListener() {
            @Override
            public void onProgressChanged(CircularSeekBar circularSeekBar, float progress, boolean fromUser) {
                //String message = String.format("Z-Achse %.2f, fromUser %s", progress-90, fromUser);
                float Zachse = (progress - 120) / 100;
                String message="";
                String CW = "cw";
                String CC = "cc";
                if (Zachse >= 0){
                    message = String.format("cw %.2f", Zachse);
                }
                if (Zachse < 0){
                    message = String.format("cc %.2f", Zachse);
                }

                //String message = String.format("",(progress-90));
                Log.d("Main", message);
                message = message.replace(",", ".");
                sendDataToRaspberryPi(message);
                //textProgress.setText(message);
                //textProgress.setText("");
            }

            @Override
            public void onStopTrackingTouch(CircularSeekBar seekBar) {
                Log.d("Main", "onStopTrackingTouch");
                textEvent.setText("");
                textProgress.setText("");
                seekBar.setProgress(120);
            }

            @Override
            public void onStartTrackingTouch(CircularSeekBar seekBar) {
                Log.d("Main", "onStartTrackingTouch");
                textEvent.setText("Touched ");
            }

        });
    }

    // Beispielmethode für die Aktion nach langem Drücken
    private void performLongPressAction(String Text) {
        // Führe hier die Aktion aus, die durch langes Drücken aktiviert wurde
        if (Text.equals("Shut Down")){
            sendDataToRaspberryPi("sd");
        }
        Toast.makeText(this, Text, Toast.LENGTH_SHORT).show();
    }

    // Beispielmethode für die Aktion nach kurzem Drücken
    private void performShortPressAction(String Text) {
        // Führe hier die Aktion aus, die für kurzes Drücken vorgesehen ist
        Toast.makeText(this, Text, Toast.LENGTH_SHORT).show();
    }

    private void startTimer(boolean run) {
        if (run == true) {  // startet Timer
            if (!isTimerRunning) {
                timer = new Timer();  // Timer initialisieren
                initializeTimerTask();  // TimerTask initialisieren
                timer.schedule(timerTask, 1000, 1000);  // Startet den Timer mit einer Verzögerung von 1 Sekunde und einem Intervall von 1 Sekunde
                isTimerRunning = true;
            }
        }
        if (run == false){   // stoppt Timer
            if (timer != null) {
                timer.cancel();  // Stoppt den Timer und alle geplanten Aufgaben
                timer = null;
                isTimerRunning = false;
            }
        }
    }
    private void initializeTimerTask() {
        timerTask = new TimerTask() {
            @Override
            public void run() {
                // TimerTask läuft auf einem Hintergrund-Thread. Um die UI zu aktualisieren, verwenden wir einen Handler
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        counter++;  // Beispielaktion: Zähler um 1 erhöhen
                        Log.d(TAG, "Der Counter läuft und steht bei "+ counter);
                    }
                });
            }
        };
    }

    private void displayStatus(String status){
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ImageView ic = (ImageView) findViewById(R.id.cutter);
                ImageView BT = (ImageView) findViewById(R.id.BTLogo);
                TextView msg = (TextView) findViewById(R.id.Textfeld);
                TextView mow = (TextView) findViewById(R.id.moweron);
                Button sd = (Button)findViewById(R.id.automow);
                TextView tbatt = findViewById(R.id.batt);
                ImageView bt = findViewById(R.id.Batterie);

                if (! status.equals("ON")) {
                    BT.setImageResource(R.drawable.ic_baseline_bluetooth_24);
                    bt.setImageResource(R.drawable.img_batterie100);
                    ic.setImageResource(R.drawable.cutteroff);
                    mow.setText("Mower On");
                    sd.setText("Start Mowing");
                    tbatt.setText("--");
                    msg.setText(status);
                }
                if (status.equals("ON")) {
                    BT.setImageResource(R.drawable.ic_baseline_bluetooth_connected_24);
                    msg.setText("");
                }
            }
        });
    }

    private void startBTServer() {

        new Thread(() -> {
            try {
                // Create a BluetoothServerSocket for listening
                if (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    Log.d(TAG, "Server started. Waiting for connection...");
                    displayStatus("Server started. Waiting for connection...");
                    serverSocket = bluetoothAdapter.listenUsingRfcommWithServiceRecord(APP_NAME, MY_UUID);
                    Log.d(TAG, "MyUUID = "+ MY_UUID);
                    // Wait for a connection (blocking call)
                    socket = serverSocket.accept();
                    //startTimer(true);  //startet den Heartbeat
                    Global.connetcted=1;
                    Log.d(TAG, "Client connected!");
                    displayStatus("ON");
                    inputStream = socket.getInputStream();
                    outputStream = socket.getOutputStream();

                    // Listen for incoming messages from the client
                    byte[] buffer = new byte[1024];
                    int bytes;
                    while (true) {
                        try {
                            bytes = inputStream.read(buffer);
                            String receivedMessage = new String(buffer, 0, bytes);
                            Log.d(TAG, "Received: " + receivedMessage);
                            decode(receivedMessage);
                            // Echo back the received message
                            //outputStream.write(("Echo: " + receivedMessage).getBytes());
                        } catch (IOException e) {
                            Log.d(TAG, "Connection lost", e);
                            Global.connetcted=0;
                            break;
                        }
                    }
                }

            } catch (IOException e) {
                Log.d(TAG, "Error starting server", e);
                displayStatus("Error starting server");
            } finally {
                displayStatus("Server beendet");
                /*
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                      ImageView ic = (ImageView) findViewById(R.id.cutter);
                      ImageView BT = (ImageView) findViewById(R.id.BTLogo);
                      Global.connetcted=0;
                      TextView msg = findViewById(R.id.Textfeld);
                      msg.setText("Server Beendet");
                        // ImageView aktualisieren
                      BT.setImageResource(R.drawable.ic_baseline_bluetooth_24);
                      ic.setImageResource(R.drawable.cutteroff);
                    }
                });
                */
                closeServer();
            }
        }).start();
    }
    public void decode(String msg){
        // Received: 4;19.83;0
        //protokoll könnte so aussehen:
        //       1       ;  14.5 ;     1  ;   237    ;12.10.13:45;     75   ;823;
        // Battery Sombol;BattSpg;MowMotor; Heading  ; Start     ;  laufzeit;Meter
        //Log.d("Decode", ""+msg);
        TextView recv = findViewById(R.id.Textfeld);
        TextView tbatt = findViewById(R.id.batt);
        TextView mow = (TextView) findViewById(R.id.moweron);
        ImageView ic = findViewById(R.id.cutter);
        ImageView bt = findViewById(R.id.Batterie);
        ImageView Compass = (ImageView) findViewById(R.id.Compassrose);
        heading = (TextView) findViewById(R.id.teledata);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // TextView aktualisieren
                //recv.setText(msg);
                /*
                if (msg.equals("M0")){
                    ic.setImageResource(R.drawable.cutteroff);
                    return;
                }
                if (msg.equals("M1")){
                    ic.setImageResource(R.drawable.cutteron);
                    return;
                }
                */
                if (msg.contains(";")) {
                    if (Global.connetcted == 1) {
                        String[] volt = msg.split(";");
                        //Log.d("Batterie", "" + volt);
                        if (volt.length > 0) {
                            tbatt.setText(volt[1] + "V");   // hier wird die Batteriespg. extrahiert
                        }
                        if (volt[0].equals("4")) {
                            bt.setImageResource(R.drawable.img_batterie100);
                        }
                        if (volt[0].equals("3")) {
                            bt.setImageResource(R.drawable.img_batterie75);
                        }
                        if (volt[0].equals("2")) {
                            bt.setImageResource(R.drawable.img_batterie50);
                        }
                        if (volt[0].equals("1")) {
                            bt.setImageResource(R.drawable.img_batterie50);
                        }
                        if (volt[2].equals("0")) {
                            ic.setImageResource(R.drawable.cutteroff);
                            mow.setText("Mower On");
                        }
                        if (volt[2].equals("1")) {
                            ic.setImageResource(R.drawable.cutteron);
                            mow.setText("Mower Off");
                        }

                        try{
                            float cv = Float.parseFloat(volt[3]);
                            Compass.setRotation(cv * -1);
                            heading.setText(String.valueOf((int) cv));
                        } catch (Exception e){
                            Log.d(TAG, "Fehler", e);
                        }


                    }
                }

            }
        });
    }


    @SuppressLint("ClickableViewAccessibility")
    public void MakeBall() {
        Global.Joydata="";
        //sp = getSharedPreferences("MyUserPrefs", Context.MODE_PRIVATE);
        //heading = (TextView) findViewById(R.id.teledata);
        tvdirection = (TextView) findViewById(R.id.direction);

        layout_joystick = (RelativeLayout) findViewById(R.id.layout_joystick);


        js = new JoyStickClass(getApplicationContext(), layout_joystick, R.drawable.image_button);
        js.setStickSize(200, 200);
        js.setLayoutSize(600, 600);
        js.setLayoutAlpha(150);
        js.setStickAlpha(100);
        js.setOffset(90);
        js.setMinimumDistance(30);
        js.drawcenter();

        //infinite loop checker for every 100ms of the joystick's direction
        //this is done through the use of sharedpreferences (saved data when we putString() at ontouchlistener)
        //we use ObjectAnimator to move the ball according to joystick's direction
        final Handler handler1 = new Handler();
        handler1.postDelayed(new Runnable() {
            @Override
            public void run() {
                //String joystickdirection = sp.getString("joystickdirection", "0");
                handler1.postDelayed(this, 100);
            }
        }, 10);


        layout_joystick.setOnTouchListener(new OnTouchListener() {
            public boolean onTouch(View arg0, MotionEvent arg1) {
                if (Global.connetcted==0){
                    startBTServer();
                }
                js.drawStick(arg1);
                //Log.d("Joystick","Arg0 "+arg0+" Arg1 "+arg1);
                final DecimalFormat df = new DecimalFormat("0.00");
                if (arg1.getAction() == MotionEvent.ACTION_DOWN || arg1.getAction() == MotionEvent.ACTION_MOVE) {
                    float a = js.getAngle();
                    float d = js.getDistance();
                    int an = (int) a;
                    String jdata = "";  // Daten vom Joystick
                    //jdata=df.format(a)+ ";" + df.format(d);
                    jdata= df.format(d)+" "+an +" ";
                    jdata = jdata.replace(",", ".");
                    if (!jdata.equals(Global.Joydata)) {
                           //heading.setText(jdata);
                           sendDataToRaspberryPi(jdata);
                           Global.Joydata=jdata;
                    }

                    int direction = js.get8Direction();
                    if (direction == JoyStickClass.STICK_UP) {
                        tvdirection.setText("Direction : Up");


                    } else if (direction == JoyStickClass.STICK_UPRIGHT) {
                        tvdirection.setText("Direction : Up Right");
                    } else if (direction == JoyStickClass.STICK_RIGHT) {
                        tvdirection.setText("Direction : Right");
                    } else if (direction == JoyStickClass.STICK_DOWNRIGHT) {
                       tvdirection.setText("Direction : Down Right");
                    } else if (direction == JoyStickClass.STICK_DOWN) {
                        tvdirection.setText("Direction : Down");
                    } else if (direction == JoyStickClass.STICK_DOWNLEFT) {
                        tvdirection.setText("Direction : Down Left");
                    } else if (direction == JoyStickClass.STICK_LEFT) {
                        tvdirection.setText("Direction : Left");
                    } else if (direction == JoyStickClass.STICK_UPLEFT) {
                        tvdirection.setText("Direction : Up Left");
                    } else if (direction == JoyStickClass.STICK_NONE) {
                        tvdirection.setText("Direction : Center");
                    }
                } else if (arg1.getAction() == MotionEvent.ACTION_UP) {
                    //heading.setText("");
                    tvdirection.setText("Direction :");
                    sendDataToRaspberryPi("0.00 0");
                    js.drawcenter();
                 }
                return true;
            }
        });

    }

    private void sendDataToRaspberryPi(String message) {

        if (outputStream != null) {
            try {
                outputStream.write(message.getBytes());
                Log.d(TAG, "Data sent: " + message);
            } catch (IOException e) {
                Log.d(TAG, "Error sending data", e);
            }
        } else {
            Log.e(TAG, "OutputStream is null. Could not send data.");
        }
    }

    // Hilfsfunktion, um die passende Characteristic zu finden
    private void closeServer() {
        startTimer(false);//stoppt den Heartbeat
        try {
            if (inputStream != null) inputStream.close();
            if (outputStream != null) outputStream.close();
            if (socket != null) socket.close();
            if (serverSocket != null) serverSocket.close();
        } catch (IOException e) {
            Log.e(TAG, "Error closing server", e);
        }
    }

@Override
protected void onDestroy() {
    super.onDestroy();
    closeServer();
}
}