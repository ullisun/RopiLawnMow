package com.example.mybleapp;

public class Global {
    public static int ivar1, connetcted;
    public static String Joydata, svar2;
    public static int[] myarray1 = new int[10];

}
